# APK Build Guide

1. GitHub repo খুলুন
2. এই ZIP extract করে সব files repo root-এ upload করুন
3. Root-এ এগুলো থাকতে হবে:
   - app/
   - .github/
   - build.gradle
   - settings.gradle
4. Actions tab খুলুন
5. Build NEXO Android v2.0 APK select করুন
6. Run workflow চাপুন
7. Build complete হলে Artifacts থেকে APK download করুন
