# NEXO Android v2.0 Professional Pilot Source

এই source GitHub Actions দিয়ে APK বানানোর জন্য।

## Features
- Default server: https://nexoofficial.in/mobile/?app=android&v=300
- Camera permission
- Microphone permission
- WebView permission handler for Jitsi/WebRTC
- File picker support
- HTTPS only
- NEXO app name
- ASTRA Technologies copyright server UI থেকে দেখাবে

## Build
GitHub repo-তে source files upload/extract করে দিন। তারপর:

Actions → Build NEXO Android v2.0 APK → Run workflow

Artifact download করুন:
NEXO-Android-v2.0-Professional-Pilot-debug-apk

## Note
এটা pilot/debug APK। Final public release করার আগে signed release APK বানাতে হবে।
